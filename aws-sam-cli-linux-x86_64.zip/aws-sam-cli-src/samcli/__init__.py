"""
SAM CLI version
"""

__version__ = "1.138.0"
